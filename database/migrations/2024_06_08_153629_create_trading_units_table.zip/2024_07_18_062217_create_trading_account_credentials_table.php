<?php
//
//use Illuminate\Database\Migrations\Migration;
//use Illuminate\Database\Schema\Blueprint;
//use Illuminate\Support\Facades\Schema;
//
//return new class extends Migration
//{
//    /**
//     * Run the migrations.
//     */
//    public function up(): void
//    {
//        Schema::create('trading_account_credentials', function (Blueprint $table) {
//            $table->id();
//            $table->unsignedBigInteger('user_id');
//            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
//            $table->unsignedBigInteger('trading_individual_id');
//            $table->foreign('trading_individual_id')->references('id')->on('trading_individuals')->onDelete('cascade');
//            $table->unsignedBigInteger('funder_id');
//            $table->foreign('funder_id')->references('id')->on('funders')->onDelete('cascade');
//            $table->string('account_id');
//            $table->string('starting_balance');
//            $table->string('login_username')->nullable();
//            $table->string('login_password')->nullable();
//            $table->string('account_type');
//            $table->string('status')->nullable();
//            $table->timestamps();
//        });
//    }
//
//    /**
//     * Reverse the migrations.
//     */
//    public function down(): void
//    {
//        Schema::table('trading_account_credentials', function (Blueprint $table) {
//            $table->dropForeign(['user_id']);
//            $table->dropColumn('user_id');
//            $table->dropForeign(['funder_id']);
//            $table->dropColumn('funder_id');
//            $table->dropForeign(['trading_individual_id']);
//            $table->dropColumn('trading_individual_id');
//        });
//        Schema::dropIfExists('trading_account_credentials');
//    }
//};
