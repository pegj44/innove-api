<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TradingAccountCredential extends Model
{
    use HasFactory;

    protected $fillable = [
        'account_id',
        'user_account_id',
        'funder_id',
        'funder_account_id',
        'starting_balance',
        'asset_type',
        'symbol',
        'current_phase',
        'phase_1_total_target_profit',
        'phase_1_daily_target_profit',
        'phase_1_max_drawdown',
        'phase_1_daily_drawdown',
        'phase_2_total_target_profit',
        'phase_2_daily_target_profit',
        'phase_2_max_drawdown',
        'phase_2_daily_drawdown',
        'phase_3_total_target_profit',
        'phase_3_daily_target_profit',
        'phase_3_max_drawdown',
        'phase_3_daily_drawdown',
        'status',
        'platform_type',
        'platform_url',
        'platform_login_username',
        'platform_login_password',
    ];

    public $attributes = [
        'phase_1_total_target_profit' => '',
        'phase_1_daily_target_profit' => '',
        'phase_1_max_drawdown' => '',
        'phase_1_daily_drawdown' => '',
        'phase_2_total_target_profit' => '',
        'phase_2_daily_target_profit' => '',
        'phase_2_max_drawdown' => '',
        'phase_2_daily_drawdown' => '',
        'phase_3_total_target_profit' => '',
        'phase_3_daily_target_profit' => '',
        'phase_3_max_drawdown' => '',
        'phase_3_daily_drawdown' => '',
        'status' => 'active',
        'platform_url' => '',
        'platform_login_username' => '',
        'platform_login_password' => '',
    ];

    public function account()
    {
        return $this->belongsTo(AccountModel::class, 'account_id');
    }

    public function funder()
    {
        return $this->belongsTo(Funder::class, 'funder_id');
    }

    public function userAccount()
    {
        return $this->belongsTo(TradingIndividual::class, 'user_account_id');
    }

    public function tradeReports()
    {
        return $this->hasMany(TradeReport::class);
    }
}
